# -*- coding: utf-8 -*-
"""
ZenFi - interpretação de mensagens financeiras escritas em português.

    interpretar("Gastei R$ 35 no almoço")
    -> {"tipo": "despesa", "centavos": 3500, "descricao": "Almoço",
        "categoria": "Alimentação", "data": date(...)}

Só usa a biblioteca padrão. Retorna None quando não entende a mensagem
(sem valor, sem verbo de receita/despesa, valor absurdo etc.): nesse caso o
servidor NÃO lança nada e pede para a pessoa reescrever.
"""
import re
import unicodedata
from datetime import date, timedelta

# Categorias que existem no app (CATS do HTML). "Outros" é o padrão.
CATEGORIAS = [
    "Moradia", "Alimentação", "Transporte", "Saúde", "Educação", "Lazer",
    "Contas e serviços", "Dízimo", "Oferta", "Seguro", "Escola", "Mercado",
    "Internet fixa", "Internet móvel", "Feira", "Padaria", "Meus Cuidados",
    "Outros",
]

MAX_CENTAVOS = 10_000_000_00  # R$ 10 milhões por mensagem

RECEITA = (
    "recebi", "recebimento", "ganhei", "salario", "entrou", "caiu na conta",
    "vendi", "venda", "freela", "freelance", "rendimento", "rendeu", "reembolso",
    "restituicao", "deposito", "depositaram", "me pagaram", "pagaram",
    "comissao", "bonus", "13o", "decimo terceiro", "ferias", "aluguel recebido",
)
DESPESA = (
    "gastei", "gasto", "gastos", "paguei", "pagamento", "pago", "comprei", "compra",
    "despesa", "debitou", "saiu", "boleto", "parcela", "fatura", "assinatura",
    "transferi", "pix para", "doei", "paguei",
)

# (regex sobre texto normalizado, categoria) - a primeira que casar vence.
REGRAS_CATEGORIA = [
    (r"\bdizimo", "Dízimo"),
    (r"\boferta\b", "Oferta"),
    (r"\bpadaria|\bpao\b|\bpaes\b", "Padaria"),
    (r"\bfeira\b|\bhortifruti|\bsacolao", "Feira"),
    (r"\bsupermercado|\bmercado\b|\bmercadinho|\batacadao|\bcompras do mes", "Mercado"),
    (r"\balmoco|\bjantar|\bjanta\b|\blanche|\brestaurante|\bifood|\bcafe\b|\bpizza|\bhamburguer|\bsorvete|\bmarmita|\bbar\b|\bcerveja|\bcafeteria|\bcomida|\bcafe da manha", "Alimentação"),
    (r"\bgasolina|\bcombustivel|\betanol|\bdiesel|\buber\b|\b99\b|\btaxi|\bonibus|\bmetro\b|\bpassagem|\bestacionamento|\bpedagio|\bmecanico|\boficina|\bipva|\bcarro\b|\bmoto\b", "Transporte"),
    (r"\bfarmacia|\bremedio|\bmedico|\bconsulta|\bdentista|\bexame|\bhospital|\bplano de saude|\bsaude\b|\bterapia|\bpsicologo", "Saúde"),
    (r"\bescola\b|\bcreche|\bcolegio|\bmaterial escolar", "Escola"),
    (r"\bcurso|\bfaculdade|\buniversidade|\blivro|\bmensalidade|\bapostila|\bidioma|\bingles", "Educação"),
    (r"\bcinema|\bshow\b|\bviagem|\bhotel|\bnetflix|\bspotify|\bdisney|\bamazon prime|\bstreaming|\bjogo|\bgame|\bpasseio|\bparque|\bfesta|\bladrilho|\blazer", "Lazer"),
    (r"\binternet|\bwifi|\bwi-fi|\bfibra|\bbanda larga", "Internet fixa"),
    (r"\bcelular|\brecarga|\bplano de celular|\bdados moveis|\b4g\b|\b5g\b", "Internet móvel"),
    (r"\bseguro", "Seguro"),
    (r"\baluguel|\bcondominio|\biptu|\bfinanciamento|\breforma|\bmoveis|\bmovel\b|\bmorad", "Moradia"),
    (r"\bluz\b|\benergia|\bagua\b|\bgas\b|\btelefone|\bconta de luz|\bconta de agua|\besgoto|\btv a cabo|\bboleto", "Contas e serviços"),
    (r"\bsalao|\bbarbeiro|\bcabelo|\bunha|\bmanicure|\bcosmetico|\bperfume|\bacademia|\bskincare|\bmaquiagem", "Meus Cuidados"),
]

PALAVRAS_RUIDO = {
    "reais", "real", "conto", "contos", "gastei", "gasto", "gastos", "paguei", "pagamento",
    "pago", "comprei", "compra", "recebi", "recebimento", "ganhei", "entrou", "caiu", "vendi",
    "de", "do", "da", "dos", "das", "no", "na", "nos", "nas", "em", "com", "um", "uma", "o", "a",
    "os", "as", "foi", "foram", "hoje", "ontem", "anteontem", "dia", "para", "pra", "por", "pelo",
    "pela", "r", "rs", "reais.", "meu", "minha", "me", "conta", "na conta", "lancar", "lancei",
    "despesa", "debitou", "saiu", "transferi", "e", "que", "ao", "aos",
}


def _sem_acento(s):
    return "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")


def normalizar(s):
    return re.sub(r"\s+", " ", _sem_acento(str(s or "")).lower()).strip()


def _para_centavos(bruto):
    """'2.500,50' -> 250050 ; '35' -> 3500 ; '1.200' -> 120000 ; '35.5' -> 3550."""
    s = bruto.strip()
    if "," in s:
        s = s.replace(".", "").replace(",", ".")
    elif s.count(".") > 1:
        s = s.replace(".", "")
    elif re.fullmatch(r"\d{1,3}\.\d{3}", s):
        s = s.replace(".", "")
    try:
        return int(round(float(s) * 100))
    except ValueError:
        return None


_NUM = r"\d{1,3}(?:\.\d{3})+(?:,\d{1,2})?|\d+(?:[.,]\d{1,2})?"


def _extrair_valor(t):
    """Devolve (centavos, trecho) escolhendo o número que é dinheiro, não data."""
    # tira datas e "dia N" para não confundir com valor
    limpo = re.sub(r"\b\d{1,2}/\d{1,2}(?:/\d{2,4})?\b", " ", t)
    limpo = re.sub(r"\bdia\s+\d{1,2}\b", " ", limpo)
    # 1) número com R$ antes
    m = re.search(r"r\$\s*(" + _NUM + r")(\s*mil\b)?", limpo)
    if not m:
        # 2) número seguido de reais/conto
        m = re.search(r"(" + _NUM + r")(\s*mil\b)?\s*(?:reais|real|contos?|pila|pilas)\b", limpo)
    if not m:
        # 3) qualquer número solto (o primeiro)
        m = re.search(r"(?<![\w/])(" + _NUM + r")(\s*mil\b)?(?![\w/])", limpo)
    if not m:
        return None, None
    c = _para_centavos(m.group(1))
    if c is not None and m.group(2):
        c *= 1000
    return c, m.group(0)


def _extrair_data(t, hoje):
    """Retorna (data, trecho_removido). Padrão: hoje."""
    if re.search(r"\banteontem\b", t):
        return hoje - timedelta(days=2), "anteontem"
    if re.search(r"\bontem\b", t):
        return hoje - timedelta(days=1), "ontem"
    m = re.search(r"\b(\d{1,2})/(\d{1,2})(?:/(\d{2,4}))?\b", t)
    if m:
        d, mes = int(m.group(1)), int(m.group(2))
        ano = hoje.year
        if m.group(3):
            ano = int(m.group(3))
            ano += 2000 if ano < 100 else 0
        try:
            dt = date(ano, mes, d)
            if not m.group(3) and dt > hoje + timedelta(days=1):
                dt = date(ano - 1, mes, d)  # "28/12" dito em janeiro = ano passado
            return dt, m.group(0)
        except ValueError:
            pass
    m = re.search(r"\bdia\s+(\d{1,2})\b", t)
    if m:
        d = int(m.group(1))
        ano, mes = hoje.year, hoje.month
        if d > hoje.day + 1:  # "dia 28" dito no dia 5 -> mês passado
            mes -= 1
            if mes == 0:
                mes, ano = 12, ano - 1
        for dd in (d, d - 1, d - 2, d - 3):  # dia 31 em mês curto
            try:
                return date(ano, mes, dd), m.group(0)
            except ValueError:
                continue
    return hoje, ""


def _tipo(t):
    receita = any(re.search(r"\b" + re.escape(k), t) for k in RECEITA)
    despesa = any(re.search(r"\b" + re.escape(k), t) for k in DESPESA)
    if receita and not despesa:
        return "receita"
    if despesa and not receita:
        return "despesa"
    if receita and despesa:
        # "recebi ... paguei": vence o verbo que aparece primeiro
        pr = min((m.start() for k in RECEITA for m in [re.search(r"\b" + re.escape(k), t)] if m), default=9999)
        pd = min((m.start() for k in DESPESA for m in [re.search(r"\b" + re.escape(k), t)] if m), default=9999)
        return "receita" if pr <= pd else "despesa"
    return None


def categoria_para(t_normalizado):
    for rx, cat in REGRAS_CATEGORIA:
        if re.search(rx, t_normalizado):
            return cat
    return "Outros"


def _descricao(original, trecho_valor, trecho_data, tipo, categoria):
    s = original
    for pedaco in (trecho_valor, trecho_data):
        if pedaco:
            # remove ignorando acentos/caixa: procura no texto normalizado e corta no original
            ns = normalizar(s)
            i = ns.find(pedaco)
            if i >= 0 and len(ns) == len(s):
                s = re.sub(r"\s+", " ", s[:i] + " " + s[i + len(pedaco):]).strip()
    s = re.sub(r"r\$\s*", " ", s, flags=re.I)
    palavras = [p for p in re.split(r"\s+", s.strip()) if p]
    while palavras and normalizar(palavras[0]).strip(".,!") in PALAVRAS_RUIDO:
        palavras.pop(0)
    while palavras and normalizar(palavras[-1]).strip(".,!") in PALAVRAS_RUIDO:
        palavras.pop()
    desc = " ".join(palavras).strip(" .,;:-!")
    if not desc:
        return categoria if categoria != "Outros" else ("Receita" if tipo == "receita" else "Despesa")
    desc = desc[:60]
    return desc[0].upper() + desc[1:]


def interpretar(texto, hoje=None):
    """Retorna dict ou None. `hoje` existe para os testes."""
    hoje = hoje or date.today()
    original = re.sub(r"\s+", " ", str(texto or "")).strip()
    if not original or len(original) > 300:
        return None
    t = normalizar(original)
    tipo = _tipo(t)
    if not tipo:
        return None
    centavos, trecho_valor = _extrair_valor(t)
    if not centavos or centavos <= 0 or centavos > MAX_CENTAVOS:
        return None
    data, trecho_data = _extrair_data(t, hoje)
    if data > hoje + timedelta(days=1) or data < hoje - timedelta(days=400):
        return None
    # a categoria só faz sentido para despesas (receitas do app não têm categoria)
    cat = categoria_para(t) if tipo == "despesa" else ""
    desc = _descricao(original, trecho_valor, trecho_data, tipo, cat or "Outros")
    return {"tipo": tipo, "centavos": centavos, "descricao": desc,
            "categoria": cat, "data": data}

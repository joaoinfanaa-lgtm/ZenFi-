# -*- coding: utf-8 -*-
"""Teste no navegador (Playwright): dois "celulares", cadastro, login, nuvem, WhatsApp, senha, plano.
    python tests/e2e_browser.py   (precisa de: pip install playwright && playwright install chromium)"""
import json, os, sys, threading, time, hmac, hashlib, http.client
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import test_zenfi as T
from http.server import HTTPServer
from playwright.sync_api import sync_playwright

mp = T.porta_livre(); mock = HTTPServer(("127.0.0.1", mp), T.Mock); threading.Thread(target=mock.serve_forever, daemon=True).start()
base = "http://127.0.0.1:%d" % mp
proc, porta, pasta = T.subir_servidor({"META_APP_SECRET": T.APP_SECRET, "WHATSAPP_TOKEN": "t", "WHATSAPP_PHONE_NUMBER_ID": "1",
    "WHATSAPP_API_BASE": base, "WHATSAPP_NUMERO_PUBLICO": "5511900000000", "STRIPE_SECRET_KEY": "sk", "STRIPE_PRICE_ID": "p",
    "STRIPE_WEBHOOK_SECRET": T.STRIPE_WH, "STRIPE_API_BASE": base})
URL = "http://127.0.0.1:%d/" % porta
ok = []
def passo(nome, cond, extra=""):
    ok.append(bool(cond)); print(("PASSOU  " if cond else "FALHOU  ") + nome + (" " + str(extra) if (extra and not cond) else ""))

def wa(de, texto):
    msg = {"id": "w%d" % int(time.time()*1e6), "from": de, "type": "text", "text": {"body": texto}}
    corpo = json.dumps({"object": "whatsapp_business_account", "entry": [{"changes": [{"value": {"messages": [msg]}}]}]}).encode()
    c = http.client.HTTPConnection("127.0.0.1", porta); c.request("POST", "/webhook/whatsapp", corpo, {"Content-Type": "application/json", "X-Hub-Signature-256": T.assinar_meta(corpo)})
    st = c.getresponse().status; c.close(); return st

def mes(pg, ym=None):
    return pg.evaluate("(ym)=>{var d=new Date();ym=ym||d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0');return JSON.parse(localStorage.getItem('contas-da-casa:'+ym)||'{}')}", ym)

try:
    with sync_playwright() as p:
        b = p.chromium.launch()
        A = b.new_context(viewport={"width": 390, "height": 844}).new_page()
        B = b.new_context(viewport={"width": 390, "height": 844}).new_page()
        A.goto(URL); A.wait_for_timeout(800)
        A.click("#srvSwitch"); A.wait_for_timeout(500); A.fill("#lname", "Maria"); A.fill("#semail", "maria@teste.com"); A.fill("#spass", "senha123")
        A.click("#lbtn"); A.wait_for_timeout(2000)
        passo("A) cadastro só com nome, e-mail e senha (sem CPF)", A.evaluate("fetch('/api/eu').then(r=>r.status)") == 200)
        # lança uma despesa pela interface
        A.evaluate("document.querySelector(\"#tabL\").click()"); A.fill("#billDesc", "Mercado do mês"); A.fill("#billAmt", "150,00"); A.evaluate("document.querySelector(\"#billForm button[type=submit]\").click()"); A.wait_for_timeout(2500)
        passo("A) despesa criada no app", any(x["desc"] == "Mercado do mês" for x in mes(A).get("bills", [])))
        # B: outro celular entra com a mesma conta
        B.goto(URL); B.wait_for_timeout(800)
        B.fill("#semail", "maria@teste.com"); B.fill("#spass", "senha123"); B.click("#lbtn"); B.wait_for_timeout(3500)
        passo("B) outro celular recupera a despesa automaticamente", any(x["desc"] == "Mercado do mês" for x in mes(B).get("bills", [])), mes(B))
        # WhatsApp: vincula e lança
        A.evaluate("document.querySelector(\"#cfgBtn\").click()"); A.wait_for_timeout(600)
        passo("A) seção WhatsApp e Plano aparecem nas configurações", A.locator("#zenfiWaLink").count() == 1 and A.locator("#zenPlan").count() == 1)
        A.click("#zwaGo"); A.wait_for_selector(".zen-cod"); cod = A.inner_text(".zen-cod")
        passo("A) código de conexão gerado", cod.startswith("ZEN-"), cod)
        passo("A) link abre o WhatsApp com a mensagem pronta", "wa.me/5511900000000" in (A.get_attribute("#zenfiWaLink a.btn", "href") or ""))
        wa("5511988880000", cod); A.wait_for_timeout(4500)
        passo("A) tela mostra o número conectado", "Conectado" in A.inner_text("#zenfiWaLink"), A.inner_text("#zenfiWaLink")[:120])
        A.evaluate("document.querySelector(\"#cfgX\").click()"); A.wait_for_timeout(300)
        n0 = len(mes(A).get("bills", []))
        wa("5511988880000", "Gastei R$ 35 no almoço"); wa("5511988880000", "Recebi R$ 2.500 de salário")
        A.wait_for_timeout(9000)
        m = mes(A)
        passo("A) despesa do WhatsApp apareceu sem recarregar à mão", any(x["desc"] == "Almoço" and x["amount"] == 3500 for x in m.get("bills", [])), m)
        passo("A) receita do WhatsApp apareceu", any(x["desc"] == "Salário" and x["amount"] == 250000 for x in m.get("incomes", [])))
        B.wait_for_timeout(8000)
        passo("B) o outro celular também recebeu", any(x["desc"] == "Almoço" for x in mes(B).get("bills", [])))
        txt = A.evaluate("document.body.innerText")
        passo("A) lançamento do WhatsApp visível na tela", "Almoço" in txt or "Salário" in txt)
        A.screenshot(path="/home/claude/e2e_painel.png")
        # edição em B volta para A
        B.evaluate("document.querySelector(\"#tabL\").click()"); B.fill("#billDesc", "Farmácia"); B.fill("#billAmt", "42,00"); B.evaluate("document.querySelector(\"#billForm button[type=submit]\").click()"); B.wait_for_timeout(1500)
        A.wait_for_timeout(9000)
        passo("A) recebe o que foi lançado em B", any(x["desc"] == "Farmácia" for x in mes(A).get("bills", [])))
        # esqueci a senha
        C = b.new_context(viewport={"width": 390, "height": 844}).new_page()
        C.goto(URL); C.wait_for_timeout(900)
        passo("C) link 'Esqueci minha senha' visível no login", C.locator("#lforgot").is_visible())
        C.click("#lforgot"); C.fill("#zenRecEmail", "maria@teste.com"); C.click("#zenRecGo"); C.wait_for_timeout(1000)
        passo("C) pedido de recuperação aceito", "enviamos um link" in C.inner_text("#zenRecMsg"))
        r = http.client.HTTPConnection("127.0.0.1", porta); r.request("POST", "/api/senha/esqueci", json.dumps({"email": "maria@teste.com"}), {"Content-Type": "application/json"})
        link = json.loads(r.getresponse().read())["dev_link"]; r.close()
        C.goto(URL + "#" + link.split("#")[1]); C.reload(); C.wait_for_timeout(800)
        C.fill("#zenNp1", "novasenha9"); C.fill("#zenNp2", "novasenha9"); C.click("#zenNpGo"); C.wait_for_timeout(2500)
        C.fill("#semail", "maria@teste.com"); C.fill("#spass", "novasenha9"); C.click("#lbtn"); C.wait_for_timeout(3500)
        passo("C) entra com a nova senha e vê os dados", any(x["desc"] == "Mercado do mês" for x in mes(C).get("bills", [])))
        # sair limpa o aparelho
        C.evaluate("document.querySelector(\"#cfgBtn\").click()"); C.wait_for_timeout(500); C.evaluate("document.querySelector(\"#cfgOut\").click()"); C.wait_for_timeout(2500)
        passo("C) sair apaga os dados deste aparelho", not mes(C).get("bills"))
        b.close()
finally:
    proc.terminate(); mock.shutdown()
print("\n%d/%d passos OK" % (sum(ok), len(ok))); sys.exit(0 if all(ok) else 1)
